from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Internship, InternshipApplication
from django.http import HttpResponse

# Landing page view
def landing_page(request):
    return render(request, 'dashboard/landing_page.html')

@login_required
def dashboard_home(request):
    internships = Internship.objects.filter(company=request.user)
    return render(request, 'dashboard/dashboard_home.html',{'internships': internships})

@login_required
def applications_received(request):
    applications = InternshipApplication.objects.filter(internship__company=request.user)
    return render(request, 'dashboard/applications_received.html', {'applications': applications})

@login_required
def request_deferment(request, application_id):
    application = get_object_or_404(InternshipApplication, id=application_id, student=request.user)
    if application.status == 'Pending':
        application.status = 'Deferred'
        application.save()
    return redirect('dashboard:applications_received')

@login_required
def manage_internships(request):
    internships = Internship.objects.filter(company=request.user)
    return render(request, 'dashboard/manage_internships.html', {'internships': internships})

def edit_internship(request, id):
    internship = get_object_or_404(Internship, id=id)
    if request.method == 'POST':
        form = InternshipApplication(request.POST, instance=internship)
        if form.is_valid():
            form.save()
            return redirect('manage_internships')
    else:
        form = InternshipApplication(instance=internship)
    return render(request, 'dashboard/edit_internship.html', {'form': form, 'internship': internship})

# View to delete an internship
def delete_internship(request, id):
    internship = get_object_or_404(Internship, id=id)
    if request.method == 'POST':
        internship.delete()
        return redirect('manage_internships')
    return render(request, 'dashboard/delete_internship.html', {'internship': internship})

@login_required
def post_internship(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        Internship.objects.create(company=request.user, title=title, description=description)
        return redirect('dashboard:dashboard_home')
    return render(request, 'dashboard/post_internship.html')

@login_required
def profile_settings(request):
    return render(request, 'dashboard/profile_settings.html')