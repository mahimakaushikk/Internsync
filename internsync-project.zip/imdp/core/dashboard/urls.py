from django.urls import path
from . import views

app_name = 'dashboard'  # Define app namespace

urlpatterns = [
    path('', views.landing_page, name='landing_page'),  # Main landing page
    path('dashboard/', views.dashboard_home, name='dashboard_home'),
    path('applications_received/', views.applications_received, name='applications_received'),
    path('request_deferment/<int:application_id>/', views.request_deferment, name='request_deferment'),
    path('manage_internships/', views.manage_internships, name='manage_internships'),
    path('manage_internships/edit/<int:id>/', views.edit_internship, name='edit_internship'),
    path('manage_internships/delete/<int:id>/', views.delete_internship, name='delete_internship'),
    path('post_internships/', views.post_internship, name='post_internship'),
    path('profile_settings/', views.profile_settings, name='profile_settings'),
]