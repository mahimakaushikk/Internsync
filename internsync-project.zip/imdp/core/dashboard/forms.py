from django import forms
from .models import Internship, CompanyProfile

class InternshipForm(forms.ModelForm):
    class Meta:
        model = Internship
        fields = ['title', 'description', 'stipend', 'location', 'duration', 'eligibility']

class CompanyProfileForm(forms.ModelForm):
    class Meta:
        model = CompanyProfile
        fields = ['company_name', 'logo', 'website', 'contact_email']