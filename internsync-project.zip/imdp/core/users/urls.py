
# users/urls.py
from django.urls import path
from django.contrib.auth import views as auth_views
 
app_name ='users'

urlpatterns = [
    path('login/', auth_views.LoginView.as_view(), name='login'),
    #  path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    # path('users/', include('users.urls')),  # Users app URLs, including login
    # path('users/', include('users.urls')),  # Users app URLs
]




   