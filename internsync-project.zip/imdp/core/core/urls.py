
from django.contrib import admin
from django.urls import path, include
from dashboard import views 
# from django.conf import settings
# from django.conf.urls.static import static

urlpatterns = [
    path('', views.landing_page, name='landing_page'),  # Main landing page
    path('admin/', admin.site.urls),  # Django admin
    path('users/', include('users.urls')),
    path('dashboard/', include('dashboard.urls')),

]
# Static and Media Files (During Development)
# if settings.DEBUG:
#     urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
